================================================================
GREENHOUSE EFFECT & CLIMATE CHANGE LAB - DESKTOP EDITION
================================================================

HOW TO RUN:

1. Double-click 'Run_Greenhouse_Lab.bat' (RECOMMENDED)
   - Automatically starts the lightweight built-in Windows listener and opens the lab.
   - Works immediately on 100% of modern Windows PCs with zero blank screens.

2. Double-click 'Greenhouse_Effect_Lab.hta'
   - Windows HTML Application launcher that launches directly.

3. Double-click 'Greenhouse_Effect_Lab_App.html'
   - Opens directly in Chrome, Edge, or Firefox.
   - Includes bulletproof LocalStorage protection and crash guards.

4. Open 'Greenhouse_Effect_Lab_Packet.html'
   - Printable student sheets and teacher answer keys.
