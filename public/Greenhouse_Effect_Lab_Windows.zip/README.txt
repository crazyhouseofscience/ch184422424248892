================================================================
GREENHOUSE EFFECT & CLIMATE CHANGE LAB - DESKTOP EDITION
Designed by Keith Chapman 2026 v1.0 using Google AI Studio
================================================================

ACCESS RESTRICTION:
- Default Classroom Passcode: PAPS2026
- Teachers can customize this password inside Teacher Mode (Ctrl+Shift+T or click logo 3 times).

HOW TO RUN:
1. Double-click 'DOUBLE_CLICK_TO_RUN_OFFLINE.html' (RECOMMENDED)
   - 100% self-contained single-file bundle.
   - Runs directly in Chrome, Edge, Safari, or Firefox without any server or internet.
2. Double-click 'Run_Greenhouse_Lab.bat'
   - Starts local listener on Windows.
